export default [
  {
    id: 'QT-2024-001',
    client: 'Metro Construction Ltd.',
    project: 'Downtown Office Complex',
    value: 1250000,
    status: 'pending',
    date: '2024-01-15',
    items: [],
  },
  {
    id: 'QT-2024-002',
    client: 'Urban Developers Inc.',
    project: 'Residential Tower Phase 2',
    value: 890000,
    status: 'in-progress',
    date: '2024-01-12',
    items: [],
  },
];
